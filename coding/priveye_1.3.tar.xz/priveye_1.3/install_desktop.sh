#!/bin/sh
# Installs an app-menu launcher + icon for the Linux GUI client (current user
# only, no root needed). Run it from the folder containing client_gui:
#
#     ./install_desktop.sh            install
#     ./install_desktop.sh remove     uninstall
#
# Re-run it if you move the program to a different folder.
set -e

APP_ID="priveye-client"          # must match APP_ID in priveye.c
APP_NAME="Priveye"               # the name shown in menus / the dock
HERE="$(cd "$(dirname "$0")" && pwd)"
BIN="$HERE/priveye"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"

if [ "$1" = "remove" ]; then
    rm -f "$DATA/applications/$APP_ID.desktop"
    for s in 16 32 48 64 128 256; do
        rm -f "$DATA/icons/hicolor/${s}x${s}/apps/$APP_ID.png"
    done
    echo "Removed launcher and icons."
    exit 0
fi

if [ ! -x "$BIN" ]; then
    echo "Can't find an executable at $BIN"
    echo "Build client_gui first, and keep this script in the same folder."
    exit 1
fi

# 1. Icons, one file per size. The icon theme picks the closest to what it needs.
for s in 16 32 48 64 128 256; do
    mkdir -p "$DATA/icons/hicolor/${s}x${s}/apps"
    cp "$HERE/icons/$s.png" "$DATA/icons/hicolor/${s}x${s}/apps/$APP_ID.png"
done

# 2. The launcher entry.
#    Path= matters: the client looks for config.cfg and server.crt in its
#    WORKING DIRECTORY, and a menu launcher would otherwise start it in your
#    home folder, where they don't exist.
mkdir -p "$DATA/applications"
cat > "$DATA/applications/$APP_ID.desktop" << DESKTOP
[Desktop Entry]
Type=Application
Name=$APP_NAME
Comment=Encrypted group chat
Exec="$BIN"
Path=$HERE
Icon=$APP_ID
Terminal=false
Categories=Network;Chat;
StartupWMClass=$APP_ID
DESKTOP

# 3. Ask the desktop to notice (both optional; ignore if not installed).
update-desktop-database "$DATA/applications" 2>/dev/null || true
gtk-update-icon-cache -f -t "$DATA/icons/hicolor" 2>/dev/null || true

echo "Installed. Look for \"$APP_NAME\" in your app menu."
echo "If the old icon lingers, log out and back in (some desktops cache icons)."
